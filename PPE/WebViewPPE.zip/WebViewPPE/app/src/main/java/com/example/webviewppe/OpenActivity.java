package com.example.webviewppe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class OpenActivity extends AppCompatActivity {
    WebView web;
    MainActivity acessTexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
        getSupportActionBar().hide();
        web = findViewById(R.id.web);
        web.setWebViewClient(new WebViewClient());
        loadMyUrl("https://pt.wikipedia.org/wiki/Wikip%C3%A9dia");

        acessTexto.texto.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if(actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE){
                        loadMyUrl(acessTexto.texto.getText().toString());
                        return true;
                    }
                return false;
            }
        });
    }

    void loadMyUrl(String url){
        boolean matchUrl = Patterns.WEB_URL.matcher(url).matches();
        if(matchUrl){
            web.loadUrl(url);
        } else{
            web.loadUrl("google.com/search?q="+url);
        }
    }
}