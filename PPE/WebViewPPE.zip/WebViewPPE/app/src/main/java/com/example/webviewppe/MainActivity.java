package com.example.webviewppe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static EditText texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        texto = findViewById(R.id.texto);
    }

    public void pesquisar(View v){
        texto.setText("");

        Intent i = new Intent(this, OpenActivity.class);
        startActivity(i);
    }

    public void sobre(View v){
        Toast.makeText(this, "Meu nome é Ricardo da Silva e desejo recuperar as habilidades H1 e H2", Toast.LENGTH_LONG).show();
    }
}