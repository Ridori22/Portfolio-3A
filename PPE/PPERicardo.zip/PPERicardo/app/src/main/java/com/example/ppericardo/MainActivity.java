package com.example.ppericardo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    ViewPager2 Vp;
    TabLayout tbl;
    FragmentAdapter adap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        MontaFragment();
    }
    public void MontaFragment(){
        Vp = findViewById(R.id.viewPager2);
        tbl = findViewById(R.id.tabLayout);
        FragmentManager fm = getSupportFragmentManager();
        adap = new FragmentAdapter(fm, getLifecycle());
        Vp.setAdapter(adap);
        tbl.addTab(tbl.newTab().setText("Cadastro"));
        tbl.addTab(tbl.newTab().setText("Lista"));
        tbl.addTab(tbl.newTab().setText("Sobre Mim"));
        tbl.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Vp.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        Vp.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tbl.selectTab(tbl.getTabAt(position));
            }
        });



    }
}