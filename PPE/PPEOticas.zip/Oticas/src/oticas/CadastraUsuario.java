
package oticas;

public class CadastraUsuario {
    String Usuario;
    String CPF;

    public CadastraUsuario(String Usuario, String CPF) {
        this.Usuario = Usuario;
        this.CPF = CPF;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }
    
}
