
package oticas;

public class Oticas {

    public static void main(String[] args) {
        CadastraOculos a = new CadastraOculos("Oculos1", 150);
        CadastraOculos b = new CadastraOculos("Oculos2", 200);
        
        BancoDados.salvarOculos(a);
        BancoDados.salvarOculos(b);
    }
    
}
