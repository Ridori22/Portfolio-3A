
package oticas;

public class History {
  String usuario;
  String oculos;

    public History(String usuario, String oculos) {
        this.usuario = usuario;
        this.oculos = oculos;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getOculos() {
        return oculos;
    }

    public void setOculos(String oculos) {
        this.oculos = oculos;
    }
  
}
