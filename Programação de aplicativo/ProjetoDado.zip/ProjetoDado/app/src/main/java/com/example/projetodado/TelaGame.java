package com.example.projetodado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class TelaGame extends AppCompatActivity {
    ImageView v;
    EditText n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_game);
        getSupportActionBar().hide();
        v = findViewById(R.id.imgV);
        n = findViewById(R.id.edNd);
    }
    public void play(View view){
        Random vanderlei = new Random();
        int numDado = Integer.parseInt(n.getText().toString());
        int gerador = vanderlei.nextInt(numDado)+1;
        if (numDado == 1){
            if(gerador == 1){
                v.setImageResource(R.drawable.dado1);

            }


        }
        if (numDado == 2){
            if(gerador == 1){
                v.setImageResource(R.drawable.dado1);

            }else if(gerador == 2){
                v.setImageResource(R.drawable.dado2);

            }


        }
        if (numDado == 3){
            if(gerador == 1){
                v.setImageResource(R.drawable.dado1);

            }else if(gerador == 2){
                v.setImageResource(R.drawable.dado2);

            } else if (gerador == 3){
                v.setImageResource(R.drawable.dado3);

            }


        }
        if (numDado == 4){
            if(gerador == 1){
                v.setImageResource(R.drawable.dado1);

            }else if(gerador == 2){
                v.setImageResource(R.drawable.dado2);

            } else if (gerador == 3){
                v.setImageResource(R.drawable.dado3);

            }  else if (gerador == 4){
                v.setImageResource(R.drawable.dado4);

            }


        }
        if (numDado == 5){
            if(gerador == 1){
                v.setImageResource(R.drawable.dado1);

            }else if(gerador == 2){
                v.setImageResource(R.drawable.dado2);

            } else if (gerador == 3){
                v.setImageResource(R.drawable.dado3);

            }  else if (gerador == 4){
                v.setImageResource(R.drawable.dado4);

            }  else if (gerador == 5){
                v.setImageResource(R.drawable.dado5);

            }



        }
        if (numDado == 6){
            if(gerador == 1){
                v.setImageResource(R.drawable.dado1);

            }else if(gerador == 2){
                v.setImageResource(R.drawable.dado2);

            } else if (gerador == 3){
                v.setImageResource(R.drawable.dado3);

            }  else if (gerador == 4){
                v.setImageResource(R.drawable.dado4);

            }  else if (gerador == 5){
                v.setImageResource(R.drawable.dado5);

            } else if (gerador == 6){
                v.setImageResource(R.drawable.dado6);

            }


        }

    }
}