package com.example.myapplication;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Usuario {
    String login;
    int senha;
    int vilao;
    int heroi;
    int vitima;
    int civil;

    public Usuario() {
    }

    public Usuario(String login, int senha, int vilao, int heroi, int vitima, int civil) {
        this.login = login;
        this.senha = senha;
        this.vilao = vilao;
        this.heroi = heroi;
        this.vitima = vitima;
        this.civil = civil;
    }


    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getVilao() {
        return vilao;
    }

    public void setVilao(int vilao) {
        this.vilao = vilao;
    }

    public int getHeroi() {
        return heroi;
    }

    public void setHeroi(int heroi) {
        this.heroi = heroi;
    }

    public int getVitima() {
        return vitima;
    }

    public void setVitima(int vitima) {
        this.vitima = vitima;
    }

    public int getCivil() {
        return civil;
    }

    public void setCivil(int civil) {
        this.civil = civil;
    }



    public void salvar() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Usuario").child(login).setValue(this);

    }
}
