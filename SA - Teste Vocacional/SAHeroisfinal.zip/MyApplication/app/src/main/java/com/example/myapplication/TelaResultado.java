package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class TelaResultado extends AppCompatActivity {
    static String resultado;
    TextView tvresultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_resultado);
        getSupportActionBar().hide();
        tvresultado = findViewById(R.id.tvresultado);
        tvresultado.setText(resultado);
    }
}