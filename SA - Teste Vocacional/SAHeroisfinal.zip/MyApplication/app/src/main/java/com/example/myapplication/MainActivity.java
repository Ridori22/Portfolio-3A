package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    EditText login, senha;
    AlertDialog.Builder alertalogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = findViewById(R.id.login);
        senha = findViewById(R.id.senha);
    }

    public void iniciar(View v){
        String l2 = login.getText().toString();
        int s2 = Integer.parseInt(senha.getText().toString());
        MainActivity2.login = l2;
        MainActivity2.senha = s2;
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
    public void cadastra(View v){
        String l = login.getText().toString();
        int s = Integer.parseInt(senha.getText().toString());
        Usuario usu = new Usuario(l,s,0, 0, 0, 0);
        usu.salvar();
        Toast.makeText(this, "Cadastro concluído", Toast.LENGTH_SHORT).show();

    }
    public void verificaUsuario(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Usuarios");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean aux = false;
                String l = login.getText().toString();
                int s = Integer.parseInt(senha.getText().toString());

                for (DataSnapshot usuario : snapshot.getChildren()){
                    if(usuario.getValue(Usuario.class).getLogin().equals(l) &&
                            usuario.getValue(Usuario.class).getSenha() == s);
                    aux = true;

                }
                if(!aux){
                    alertalogin.setTitle("ERRO");
                    alertalogin.setMessage("Usuário não encontrado");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}