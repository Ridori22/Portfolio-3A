package com.example.myapplication;

public class Perguntas {
    public int contador;

    public void Perguntas(int contador){
        this.contador = contador;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
}
