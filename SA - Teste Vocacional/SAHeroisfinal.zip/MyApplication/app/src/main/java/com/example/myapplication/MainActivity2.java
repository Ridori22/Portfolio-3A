package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.renderscript.ScriptIntrinsicYuvToRGB;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity2 extends AppCompatActivity {
    RadioButton resposta1, resposta2, resposta3, resposta4;
    TextView pergunta;
    RadioGroup radiogroup;
    Usuario u = new Usuario();
    static String login;
    static int senha;
    String mensagem = "teste";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().hide();
        radiogroup = findViewById(R.id.radiogroup);
        pergunta = findViewById(R.id.pergunta);
        resposta1 = findViewById(R.id.resposta1);
        resposta2 = findViewById(R.id.resposta2);
        resposta3 = findViewById(R.id.resposta3);
        resposta4 = findViewById(R.id.resposta4);
        resposta1.setText("ajudar o próximo");
        resposta2.setText("roubar");
        resposta3.setText("nenhuma das acima");
        resposta4.setText("ser roubado");
        radiogroup.clearCheck();

    }
    int numeroPergunta = 0;
    public void mudaTela (View v){
        somaRespostas();
        resposta1.setText(resp1[numeroPergunta]);
        resposta2.setText(resp2[numeroPergunta]);
        resposta3.setText(resp3[numeroPergunta]);
        resposta4.setText(resp4[numeroPergunta]);
        pergunta.setText(perguntas[numeroPergunta]);
        radiogroup.clearCheck();
        numeroPergunta ++;
        if (numeroPergunta == 14) {
            Intent i = new Intent(this, TelaResultado.class);
            startActivity(i);

        }
    }
    public void somaRespostas(){
        if(resposta1.isChecked()&&numeroPergunta==0){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==0){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==0){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==0){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==1){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==1){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==1){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==1){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==2){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==2){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==2){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==2){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==3){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==3){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==3){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==3){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==4){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==4){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==4){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==4){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==5){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==5){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==5){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==5){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==6){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==6){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==6){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==6){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==7){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==7){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==7){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==7){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==8){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==8){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==8){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==8){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==9){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==9){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==9){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==9){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==10){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==10){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==10){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==10){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==11){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==11){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==11){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==11){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==12){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==12){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==12){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==12){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==13){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==13){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==13){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==13){
            u.civil ++;
        }
        if(resposta1.isChecked()&&numeroPergunta==14){
            u.heroi ++;
        }
        if(resposta2.isChecked()&&numeroPergunta==14){
            u.vilao ++;
        }
        if(resposta3.isChecked()&&numeroPergunta==14){
            u.vitima ++;
        }
        if(resposta4.isChecked()&&numeroPergunta==14){
            u.civil ++;
        }
        if(u.heroi > u.vilao &&  u.heroi > u.vitima &&  u.heroi > u.civil){
            String resultado = "Herói";
            TelaResultado.resultado = resultado;
            Usuario usu = new Usuario(login,senha, u.vilao, u.heroi, u.vitima, u.civil);
            usu.salvar();
        }
        else if(u.vilao > u.heroi &&  u.vilao > u.vitima &&  u.vilao > u.civil) {
            String resultado = "Vilão";
            TelaResultado.resultado = resultado;
            Usuario usu = new Usuario(login,senha, u.vilao, u.heroi, u.vitima, u.civil);
            usu.salvar();
        }
        else if(u.vitima > u.heroi &&  u.vitima > u.civil &&  u.vitima > u.vilao) {
            String resultado = "Vítima";
            TelaResultado.resultado = resultado;
            Usuario usu = new Usuario(login,senha, u.vilao, u.heroi, u.vitima, u.civil);
            usu.salvar();
        }
        else if(u.civil > u.vilao &&  u.civil > u.vitima &&  u.civil > u.heroi){
            String resultado = "Cívil";
            TelaResultado.resultado = resultado;
            Usuario usu = new Usuario(login,senha, u.vilao, u.heroi, u.vitima, u.civil);
            usu.salvar();
        }
        else{
            String resultado = "Resultado indefinido";
            TelaResultado.resultado = resultado;
        }

    }

    String resp1 []  = {"Polícia e Ladrão", "Voar","Sim", "Avisa a Polícia", "Verdadeira, sou lindo", "Bicicleta", "Um roubo","Fazer trabalho voluntário", "Descartes", "Um bom filme", "Morrer", "Nenhuma, prefiro cidades reais", "Vai pra casa", "Parceria"};

    String resp2 []  = {"Esconde Esconde", "Raio laser", "Não", "Corre", "Porque a pergunta?", "Não sabe o preço", "Moto", "Sair pra correr", "Platão", "Um filme ruim", "Cobras", "Gotham", "Sai pra comer", "Lealdade"};

    String resp3[] = {"Pega Pega", "Ficar invisível", "Depende do dia", "Não faz nada", "Depende de quem fala", "Caro", "Carro", "Praticar esportes", "Sócrates", "Mediano", "Perder algum ente querido", "Metrópolis", "Le um livro", "Honestidade"};

    String resp4[]= {"Amarelinha", "Parar o tempo", "Não sei responder", "Ajuda", "Falsa, sou feio", "Barato", "Onibus", "Ir ao cinema", "Francis Bacon", "O melhor de todos", "Ser assaltado", "Central city", "Vai dar uma caminhada", "Senso de justiça"};

    String perguntas[] = {"Qual brincadeira você mais brincava na infância?", "Qual super poder você escolheria?", "Você se considera pró-ativo?", "Você vê alguém sendo assaltado, o que você faz?", "“Você está bonito hoje” o que você acha dessa afirmação?", "O que você acha do preço do último iphone?", "Qual tipo de veículo você mais usa?", "Qual seu passatempo preferido?", "Você sabe de quem é a famosa frase “Penso, logo existo”?", "O que você achou de Homem Aranha: Sem Volta pra Casa?", "Qual o seu maior medo?", "Em qual cidade fictícia você viveria?", "Seu horário de trabalho acabou, o que você faz?", "O que você mais valoriza em um amigo?"};

}
